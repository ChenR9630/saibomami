@echo off
setlocal
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0start-desktop-windows.ps1" %*
